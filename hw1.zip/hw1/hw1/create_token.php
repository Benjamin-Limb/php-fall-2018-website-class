<?php
 // File create_token.php
 session_start();
 $email = $_POST['email'];
 $num = 10;
 $token = bin2hex(random_bytes($num));
 $_SESSION['token'] = $token;
 $subject = 'Login Token';
 $msg = "<html><body style='background-color:lavender';>";
 $msg .= "Copy and paste token:";
 $msg .= "<strong><h3 style='color:lime';>";
 $msg .= $token;
 $msg .= "</h3></strong></body></html>";
 $headers = "From: MIS6650\r\n";
 $headers .= "Content-type: text/html\r\n";
 mail($email, $subject, $msg, $headers);
 header( 'Location: e_token.php' );
?>