<?php
 // File protect.php
 class protect
 {
  function __construct()
  {
   if(!isset($_SESSION['user']))
   { header ("location: index.php"); }
  }
 }
?>
