<?php
 // File token.php
 session_start();
 $token = $_SESSION['token'];
 $gen_token = $_POST["token"];
 if($token == $gen_token)
 { header( 'Location: register.php' ); }
 else
 { header( 'Location: e_form.php' ); }
?>