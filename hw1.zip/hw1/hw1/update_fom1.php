<?php
session_start();
require_once('protect.php');
require_once('pdoCred.php');
$protect = new protect();
$vid = $_POST['choice'];
 $_SESSION['VID'] = $vid;
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = array($vid);
 $sql = "SELECT * FROM k_site WHERE vid = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				

<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<div class="login-page">
  <div class="form">
    <form class="login-form" method='post' action='up.php'>
	<div class="wrap-input100 validate-input" >
		<span > username</span>
		<input class="input100" type="text" name="user" placeholder="Username" value="<?php echo $row['VUSER']; ?>">
		
		<span class="symbol-input100">
			<i class="fa fa-user" aria-hidden="true"></i>
		</span>
	</div>
	<div class="wrap-input100 validate-input" >
		<span >Password</span>
		<input class="input100" type="text" name="pswd" placeholder="password" value="*****">
		
		<span class="symbol-input100">
			<i class="fa fa-user" aria-hidden="true"></i>
		</span>
	</div>
	<div class="wrap-input100 validate-input" >
		<span >level</span>
		<input class="input100" type="text" name="lvl" placeholder="level" value="<?php echo $row['LVL']; ?>">
		
		<span class="symbol-input100">
			<i class="fa fa-user" aria-hidden="true"></i>
		</span>
	</div>
	<div id="button_login" class="container-login100-form-btn">
		<button type="submit" class="login100-form-btn" name="login-btn">
			Update User
		</button>
	</div>
    </form>
    <form class="login-form" method='post' action='update_fom.php'>
	<div id="button_login" class="container-login100-form-btn">
		<button type="submit" class="login100-form-btn" name="login-btn">
			Return
		</button>
	</div>
    </form>
  </div>
</div>
</div>		

						
				
						 
							
						
						
	
			
						
						

					</div>

				<!--</div>-->
			</div>
		</div>
	</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>




