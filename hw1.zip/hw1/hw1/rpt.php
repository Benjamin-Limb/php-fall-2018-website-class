<?php
session_start();
require_once('protect.php');
require_once('pdoCred.php');
$protect = new protect();

if($_SESSION['lvl'] == 0){
$sql = "SELECT * FROM k_site ORDER by vid";
$obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $stmt  = $pdo->query($sql);
 $sql = "SELECT * FROM k_site WHERE ROWNUM=1";
 $fields = $pdo->query($sql);
 $pdo = null;
 $row = $fields->fetch(PDO::FETCH_ASSOC);
 $col = array_keys($row);

}
else{
$obj = new pdoCred();
$cred = $obj->getCred();
$pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
$vid = $_SESSION['VID'];
$data = array($vid);
$sql = "SELECT * FROM k_site where VID = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute($data);

$sql = "SELECT * FROM k_site WHERE ROWNUM=1";
$fields = $pdo->query($sql);
$pdo = null;
 $row = $fields->fetch(PDO::FETCH_ASSOC);
 $col = array_keys($row);


}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				
					

<table style="width: 100%; text-align:left;">

			<tr>
				<th>  <?php echo $col[0]; ?>  </th>
				<th>  <?php echo $col[1]; ?>  </th>
				<th>  <?php echo $col[5]; ?>  </th>
			</tr>
			<?php  while($row = $stmt->fetch(PDO::FETCH_ASSOC))
 			{
			?>
			<tr>
				<td>  <?php echo $row['VID']; ?>  </td>
				<td>  <?php echo $row['VUSER']; ?>  </td>
				<td>  <?php echo $row['LVL']; ?>  </td>
			</tr>

			<?php 
			} 

			?>



			</table>
	<?php echo '<p>'; ?>
                 <div id="button_login" class="container-login100-form-btn">
				             <form class="login100-form validate-form" method="post" action="welcome.php">
						 
							<button type="destroy"  value="destroy" class="login100-form-btn" name="welcome-btn">
								Welcome 
							</button>

					
				

</div>		

						
				
						 
							
						
						
	
			
						
						

					</div>

				<!--</div>-->
			</div>
		</div>
	</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>

				
			
