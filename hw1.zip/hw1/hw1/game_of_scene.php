

<?php
session_start();
require_once('protect.php');
$protect = new protect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
 						
 
<span class ="login100-form-title p-b-53">
scene game
</span>
					
					
<?php

/*
 * 3d10-scenario-generator.php
 * by Duane O'Brien - http://chaoticneutral.net
 * written for IBM DeveloperWorks
 */

/* Start off by opening up files containing the various aspects of a scenario */

$settings = explode("\n", file_get_contents('scenario.settings.txt'));
$objectives = explode("\n", file_get_contents('scenario.objectives.txt'));
$antagonists = explode("\n", file_get_contents('scenario.antagonists.txt'));
$complications = explode("\n", file_get_contents('scenario.complications.txt'));

/* Now mix them all up, and spit out the elements, combined. */

shuffle($settings);
shuffle($objectives);
shuffle($antagonists);
shuffle($complications);

echo $settings[0] . ' ' . $objectives[0] . ' ' . $antagonists[0] . ' ' . $complications[0] . "<br />\n";
?>

				<div id="button_login" class="container-login100-form-btn">
					<form class="login100-form validate-form" method="post" action="scene_game.php">
					<button type="destroy"  value="destroy" class="login100-form-btn" name="destroy-btn">
					Click here to change the scene
					</button>
					</form>
				</div>


				<div id="button_login" class="container-login100-form-btn">
					<form class="login100-form validate-form" method="post" action="welcome.php">
					<button type="destroy"  value="destroy" class="login100-form-btn" name="destroy-btn">
					Welcome Page
					</button>
					</form>
				</div>





</div>
		</div>
	</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<script>
function myFunction() {
    location.reload();
}
</script>

<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>

