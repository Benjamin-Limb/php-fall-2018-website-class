<?php
 // File krecreate.php
 require_once 'pdoCred.php';
 require_once 'salt.php';
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = array('008');
 $sql = "SELECT * FROM k_site WHERE vid = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $row = $stmt->fetch(PDO::FETCH_ASSOC);
 $pdo = null;
 $pword = $row['PSWD'];
 $vid = $row['VID'];
 $toHash = hex2bin($row['ENCODE']);
 $salt = new salt();
 $pswd_from_form = 'case';
 $test_pass = $salt->hs($row['NOS'],$toHash,$pswd_from_form);
 if($pword == $test_pass && isSet($row['NOS']))
 {
  echo '<h2><strong style="color: blue;">';
  echo 'Success! (' . "$pswd_from_form" . ')</strong></h2>';
  echo '<h3><strong style="color: lime;">';
  echo substr($pword, 0, 10) . '&nbsp;...&nbsp;';
  echo substr($pword, 118) . '</strong>';
  echo '<p><strong style="color: fuchsia;">';
  echo substr($test_pass, 0, 10) . '&nbsp;...&nbsp;';
  echo substr($test_pass, 118) . '</strong>';
 }
 else
 {
  echo '<h2><strong style="color: red;">';
  echo 'Failure!</strong></h2>'; }
?>
