<?php
 // File kencrypt.php
 require_once 'pdoCred.php';
 require_once 'salt.php';
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $sql = "SELECT * FROM k_site";
 $result = $pdo->query($sql);
 $cnt = 0;
 while($row = $result->fetch(PDO::FETCH_ASSOC))
 {
  $vuser = $row['VUSER'];
  $pword = $row['PSWD'];
  if(strlen($pword) < 128)
  {
   $vid = $row['VID'];
   $toHash = random_bytes(10);
   $hash = bin2hex($toHash);
   $salt = new salt();
   $pass = $salt->hs($row['NOS'],$toHash,$pword);
   $data = array($pass, $hash, $vid);
   $sql = "UPDATE k_site SET pswd = :pswd, encode = :hash ";
   $sql .= "WHERE vid = :id";
   $stmt = $pdo->prepare($sql);
   $stmt->execute($data);
   echo 'Password <strong style="color: indianred;">';
   echo $pword . '</strong> encrypted!<br />';
  }
  else
  {
   echo 'Password for <strong style="color: blue;">';
   echo $vuser . '</strong> already encrypted!<br />';
  }
 }
 $pdo = null;
?>