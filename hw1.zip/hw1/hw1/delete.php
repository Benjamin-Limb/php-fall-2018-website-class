<?php
 // File delete.php
 require_once('pdoCred.php');
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $vid = $_POST['choice'];
 $data = array($vid);
 $sql = "DELETE FROM k_site WHERE vid = ?";
 $stmt = $pdo->prepare($sql);
 $result = $stmt->execute($data);
 header( 'Location: delete_form.php');
?>