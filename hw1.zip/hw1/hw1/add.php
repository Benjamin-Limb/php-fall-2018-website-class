
<?php
session_start();
 // File add.php
 require_once ('pdoCred.php');
 require_once ('salt.php');
 $user = $_POST['user'];
 $pswd = $_POST['pswd'];

if(isset($_POST['lvl'])){
$lvl = $_POST['lvl'] ;
}else{ 
$lvl =1;
}

 $n = 40000;
$email='test@gmail.com';
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $sql = "SELECT MAX(vid) max FROM k_site";
 $result = $pdo->query($sql);
 $row = $result->fetch(PDO::FETCH_ASSOC);
 $max = $row['MAX'] + 1;
echo $max;
 if(strlen((string)$max) > 1)
 { $seq = '0' .  $max; }
 else
 { $seq = '00' .  $max; }
 $toHash = random_bytes(10);
 $hash = bin2hex($toHash);
 $salt = new salt();
 $pass = $salt->hs($n, $toHash, $pswd);
 $data = array($seq, $user, $pass, $n, $hash, $lvl,$email);
 $sql = "INSERT INTO k_site VALUES(?,?,?,?,?,?,?)";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
print_r($stmt);
 $pdo = null;

if($_SESSION['lvl'] == 0){
 header( 'Location: admin.php');
}
else{
 header( 'Location: index.php');
}
?>