<?php
 // chk_push.php
 function post_captcha($user_response)
 {
  $fields_string = '';
  $fields = array(
   'secret' => '6LezszUUAAAAANzMVE8MuAHgHPIvyp0VhSRV38Dx',
   'response' => $user_response
        );
  foreach($fields as $key=>$value)
  { $fields_string .= $key . '=' . $value . '&'; }
   $fields_string = rtrim($fields_string, '&');
   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
   curl_setopt($ch, CURLOPT_POST, count($fields));
   curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
   $result = curl_exec($ch);
   curl_close($ch);
   return json_decode($result, true);
 }
 $res = post_captcha($_POST['g-recaptcha-response']);
 if (!$res['success'])
 {
  $_SESSION['api'] = $res;
  $_SESSION['msg'] = 'Please complete reCAPTCHA!';
  header('Location: admin.php');
 }
 else
 {
  header('Location: push.php');
 }
?>


Create 'admin' switchboard:

'push.php'

<?php
 // File push.php
 session_start();
 require_once('protect.php');
 $protect = new protect();
?>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<div class="a">
 <form action='add_form.php' method='post' id='add'></form>
 <button type='submit' form='add'>add</button>
 <form action='update_form.php' method='post' id='update'></form>
 <button type='submit' form='update'>update</button>
 <form action='delete_form.php' method='post' id='delete'></form>
 <button type='submit' form='delete'>delete</button>
<?php echo '<p>'; ?>
 <form action='admin.php' method='post' id='back'>
  <input type='image' id='image' src='music.gif'>
 </form>
</div>