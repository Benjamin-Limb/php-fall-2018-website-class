<?php
 // File add_new.php
 session_start();
 require_once 'pdoCred.php';
 require_once 'salt.php';
 require_once 'protect.php';
 $user = $_SESSION['user'];
 $pswd = $_SESSION['pswd'];
 $lvl = $_SESSION['lvl'];
 $n = 40000;
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $sql = "SELECT MAX(vid) max FROM k_site";
 $result = $pdo->query($sql);
 $row = $result->fetch(PDO::FETCH_ASSOC);
 $max = $row['MAX'] + 1;
 if(strlen((string)$max) > 1)
 { $seq = '0' .  $max; }
 else
 { $seq = '00' .  $max; }
 $toHash = random_bytes(10);
 $hash = bin2hex($toHash);
 $salt = new salt();
 $pass = $salt->hs($n, $toHash, $pswd);
 $data = array($seq, $user, $pass, $n, $hash, $lvl);
 $sql = "INSERT INTO k_site VALUES(?,?,?,?,?,?)";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $pdo = null;
 header( 'Location: index.php');
?>