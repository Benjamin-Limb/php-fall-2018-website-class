<?php
 // File protect.php
 class protectadmin
 {
  function __construct()
  {
   if(!isset($_SESSION['user']))
   { header ("location: index.php"); }
   elseif($_SESSION['lvl'] != 0){
	header ("location: welcome.php");
   }

  }
 }
?>