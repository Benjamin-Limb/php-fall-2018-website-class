require_once 'pdoCred.php';
 session_start();
 $vid = $_POST['choice'];
 $_SESSION['VID'] = $vid;
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = array($vid);
 $sql = "SELECT * FROM k_site WHERE vid = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<div class="login-page">
  <div class="form">
    <form class="login-form" method='post' action='up.php'>
      <input type="text" name="user" value="<?php echo $row['VUSER']; ?>"/>
      <input type="password" name='pswd' value="*****"/>
      <input type="text" name='lvl' value="<?php echo $row['LVL']; ?>"/>
      <button type='submit'>update</button>
      <p class="message">click button to update data</p>
    </form>
  </div>
</div>