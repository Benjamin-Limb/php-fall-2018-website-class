<?php
session_start();
require_once('protect.php');
$protect = new protect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
	<span class ="login100-form-title p-b-100">
		Name Game
		</span>

		
	

				<div id="button_login" class="container-login100-form-btn">
					<form class="login100-form validate-form" method="post" action="name_game.php">
					<button type="destroy"  value="destroy" class="login100-form-btn" name="destroy-btn">
					Click here to change the list of names
					</button>
					</form>
				</div>


				<?php

/*
 * 3d10-name-generator.php
 * by Duane O'Brien - http://chaoticneutral.net
 * written for IBM DeveloperWorks
 */

/*
 * I've included some good name files that can be used to see the name generator.
 * One name per line, so you need to explode on newlines.
 */

$male = explode("\n", file_get_contents('names.male.txt'));
$female = explode("\n", file_get_contents('names.female.txt'));
$last = explode("\n", file_get_contents('names.last.txt'));

/* Shuffle the name arrays, or you'll get the same results every time */

shuffle($male);
shuffle($female);
shuffle($last);

/* Now dump out ten names, alternating male and female */

for ($i = 0; $i <= 10; $i++) {
    echo $male[$i] . ' ' . $last[$i] . "<br />\n";
    echo $female[$i] . ' ' . $last[$i] . "<br />\n";
}
?>
<div id="button_login" class="container-login100-form-btn">
				             <form class="login100-form validate-form" method="post" action="welcome.php">
						 
							<button type="destroy"  value="destroy" class="login100-form-btn" name="destroy-btn">
								Welcome Page
							</button>
						
						</form>
					</div>



					</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
