<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V1</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
							
			<table style="width: 100%; text-align:left;">
					<?php
						require_once('function.php');
						if(isset($_FILES['image'])){
							$errors= array();
							$file_name = $_FILES['image']['name'];
							$file_size =$_FILES['image']['size'];
							$file_tmp =$_FILES['image']['tmp_name'];
							$file_type=$_FILES['image']['type'];
							$file_ext=strtolower(end(explode('.',$file_name)));
						

							$expensions= array("csv");
							
							if(in_array($file_ext,$expensions)=== false){
								$errors[]="extension not allowed, please choose a csv file.";
							}
							
							if($file_size > 2097152){
								$errors[]='File size must be excately 2 MB';
							}
							if(isset($_SESSION['array'])){
								unset($_SESSION['array']);
							}

							if(empty($errors)==true){
								ini_set('max_execution_time', 3600);
								$_SESSION['array'] = csv_to_array($file_tmp,",");
								$size  = sizeof($_SESSION['array']);
								$counter = 0;
								$Keynames = array_keys($_SESSION['array'][0]);
		
							?>
					
						<tr>
							<?php
							    
								foreach($Keynames as $names){
							?>
										<th>  <?php echo $names; ?>  </th>
							<?php		
								}
							?>	
						</tr>
							<?php
								foreach($_SESSION['array'] as $item){
							?>
							<tr>
								<td><?php echo $item['BatchNumber']; ?></td>
								<td><?php echo $item['MachineNumber']; ?></td>
								<td><?php echo $item['ProductCode']; ?></td>
								<td><?php echo $item['TimeStarted']; ?></td>
								<td><?php echo $item['TimeStopped']; ?></td>
								<td><?php echo $item['NumberProduced']; ?></td>
								<td><?php echo $item['NumberRejected']; ?></td>
							</tr>
							<?php 
								} 
							}
							else{
								print_r($errors);
							}
						}
							
							?>
				</table>

				<form class="login-form" action="" method="POST" enctype="multipart/form-data">
		  			<input type="file" name="image" />
          			<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn">
							Upload File
						</button>
					</div>
        		</form>  
				<form action="index.php">
					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn">
							Back to Welcome Page
						</button>
					</div>
				</form>

			
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>