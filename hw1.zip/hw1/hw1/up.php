<?php
 // File up.php
 require_once 'pdoCred.php';
 require_once 'salt.php';
 session_start();
 $vid = $_SESSION['VID'];
 $user = $_POST['user'];
 $pswd = $_POST['pswd'];
 $lvl = $_POST['lvl'];
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = array($vid);
 $sql = "SELECT * FROM k_site WHERE vid = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $row = $stmt->fetch(PDO::FETCH_ASSOC);
 $toHash = random_bytes(10);
 $hash = bin2hex($toHash);
 $salt = new salt();
 if ($pswd == '*****')
 { $pass = $row['PSWD'];
   $hash = $row['ENCODE']; }
 else
 { $pass = $salt->hs($row['NOS'], $toHash, $pswd); }
 $data = array($user, $lvl, $pass, $hash, $vid);
 $sql = "UPDATE k_site SET vuser = :vuser, lvl = :lvl,";
 $sql .= " pswd = :pass, encode = :hash  WHERE vid = :vid";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 header( 'Location: update_fom.php');
?>