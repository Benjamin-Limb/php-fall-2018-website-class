			
<?php
session_start();
require_once('protect.php');
$protect = new protect();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				
require_once('connect.php');
 $sql = "SELECT * FROM k_site ORDER by vid";
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = $pdo->query($sql);
 echo '<p>';
 $sql = "SELECT * FROM k_site WHERE ROWNUM=1";
 $fields = $pdo->query($sql);
 $pdo = null;


<table style="width: 100%; text-align:left;">


			<tr>
				<th>  <?php echo $col[0]; ?>  </th>
				<th>  <?php echo $col[1]; ?>  </th>
				<th>  <?php echo $col[5]; ?>  </th>
$col = array_keys($row);
 echo "<div style='display: inline-block; text-align: left;'>";
 echo $col[0] . '&nbsp;' . $col[1] . '&nbsp;' . $col[3] . '&nbsp;' . $col[5];
 echo '</strong></h4>';
 while($row = $data->fetch(PDO::FETCH_ASSOC))
 {


			</tr>
			<?php  while($row = $data->fetch(PDO::FETCH_ASSOC))
 			{
			?>
			<tr>
				<td>  <?php echo $row['VID']; ?>  </td>
				<td>  <?php echo $row['VUSER']; ?>  </td>
				<td>  <?php echo $row['LVL']; ?>  </td>
			</tr>

			<?php 
			} 

			?>



			</table>

					

<?php

 echo '<h1><strong style="color:powderblue">';
 echo 'Report';
 echo '</strong></h1>';
 require_once('connect.php');
 $sql = "SELECT * FROM k_site ORDER by vid";
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = $pdo->query($sql);
 echo '<p>';
 $sql = "SELECT * FROM k_site WHERE ROWNUM=1";
 $fields = $pdo->query($sql);
 $pdo = null;
 $row = $fields->fetch(PDO::FETCH_ASSOC);
 $col = array_keys($row);
 echo "<div style='display: inline-block; text-align: left;'>";
 echo '<h4><strong style="color:salmon">';
 echo $col[0] . '&nbsp;' . $col[1] . '&nbsp;' . $col[3] . '&nbsp;' . $col[5];
 echo '</strong></h4>';
 while($row = $data->fetch(PDO::FETCH_ASSOC))
 {



 

  

echo $row['VID'] . '&nbsp;' . $row['VUSER'] . '&nbsp;';
  echo $row['NOS'] . '&nbsp;' . $row['LVL'] . '<br>';
 }
?>

	<?php echo '<p>'; ?>
<script src="destroy.js"></script>
<div style="text-align:center;" id="txtHint">
<div id="button_login" class="container-login100-form-btn">

<input type=button onClick="killSession();"
class="login100-form-btn"
value="destroy">

					
				

</div>		

						
				
						 
							
						
						
	
			
						
						

					</div>

				<!--</div>-->
			</div>
		</div>
	</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>

				
			
