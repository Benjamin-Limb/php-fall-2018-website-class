<?php
 // File verify.php
 session_start();
 require_once('pdoCred.php');
 require_once 'salt.php';
 $user = $_SESSION['user'];
 $pass = $_SESSION['pswd'];
 $obj = new pdoCred();
 $cred = $obj->getCred();
 $pdo = new PDO($cred['host'], $cred['user'], $cred['pswd']);
 $data = array($user);
 $sql = "SELECT * FROM k_site WHERE vuser = ?";
 $stmt = $pdo->prepare($sql);
 $stmt->execute($data);
 $row = $stmt->fetch(PDO::FETCH_ASSOC);

 $pdo = null;
 $db_vid = $row['VID'];
 $db_pswd = $row['PSWD'];
 $toHash = hex2bin($row['ENCODE']);
 $salt = new salt();
 if (isSet($row['NOS']))
 { $pword = $salt->hs($row['NOS'],$toHash,$pass); }
 else { $pword = '@'; }
 if ($db_pswd == $pword && isSet($row['NOS']))
 {
  $_SESSION['user'] = $row['VUSER'];
  $_SESSION['lvl'] = $row['LVL'];
 $_SESSION['VID'] = $row['VID'];
echo 'a';
  header( 'Location: welcome.php' ) ;
 }
 else {
header( 'Location: index.php'); 
echo 'b';
}
?>



