<?php
 // File salt.php
 Class salt
 {
  function hs($n,$salt,$password)
  {
   if(strlen($password) < 128)
   { $hash = hash_pbkdf2('sha512', $password, $salt, $n); }
   return $hash;
  }
 }
?>