var xhr;
xhr = new XMLHttpRequest();
function killSession(str)
{
 var url="clear.php";
 xhr.open("POST",url,true);
 xhr.setRequestHeader('Content-Type',
 'application/x-www-form-urlencoded; charset=iso-8859-1');
 xhr.send("&sid="+Math.random());
 xhr.onreadystatechange=function()
 {
  if (xhr.readyState==4)
  {
   location.href = "index.php";
  }
 }
}
