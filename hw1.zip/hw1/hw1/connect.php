<?php
 // File pdoCred.php
 class pdoCred
 {
  private $_host;
  private $_user;
  private $_pswd;
  private $_cred = array();
  public function __construct()
  {
   $this->_host = '//dbase.brigham.usu.edu:1521/orcl.brigham';
   $this->_user = 'c##a01177717';
   $this->_pswd = 'benjamin';
  }
  public function getCred()
  {
   $this->_cred['user'] = $this->_user;
   $this->_cred['pswd'] = $this->_pswd;
   $this->_cred['host'] = "oci:dbname=$this->_host";
   return $this->_cred;
  }
 }
?>